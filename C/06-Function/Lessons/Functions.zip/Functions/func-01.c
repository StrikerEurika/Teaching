#include <stdio.h>

// non-parameter and non-return function
void greet() {
    printf("Hello! Welcome to the function lesson.\n");
}

int main() {
    
    // Calling the greet function
    greet();
    greet();
    greet();
    greet();
    greet();

    return 0;
}






















