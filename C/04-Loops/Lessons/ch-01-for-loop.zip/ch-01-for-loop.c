#include <stdio.h>
#include <stdlib.h>

int main() {
    system("cls");

    int i = 0;
    for (i = 0; i < 5; i++) {
        printf("Hello World %d\n", i);
    }
    return 0;
}