#include <stdio.h>
int main() {
    // Create a variable and assign the value 15 to it
    int myNum = 15;

    // Declare a variable without assigning it a value
    int myOtherNum;

    // Assign the value of myNum to myOtherNum
    myOtherNum = myNum;

    // myOtherNum now has 15 as a value
    printf("%d", myOtherNum);
}