#include <stdio.h>

int main() {
    int myNum = 15;

    printf("my number is %d", myNum); // Outputs 15

    return 0;
}