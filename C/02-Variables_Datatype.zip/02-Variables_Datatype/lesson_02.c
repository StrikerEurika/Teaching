#include <stdio.h>
int main() {

    int myNum = 15;          
    float myFloatNum = 5.99; 
    char myLetter = 'Z';

    // Print variables
    printf("%d\n", myNum);
    printf("%f\n", myFloatNum);
    printf("%c\n", myLetter);
    return 0;
}

