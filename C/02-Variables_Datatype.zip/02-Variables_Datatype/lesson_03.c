#include <stdio.h>

// naming convention
int main() {
    
    
}