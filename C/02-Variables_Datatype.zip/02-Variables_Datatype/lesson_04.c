#include <stdio.h>
int main() {
    printf("My favorite number is: %d", 15);
    printf("My favorite letter is: %c", 'D');
}